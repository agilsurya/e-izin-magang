<?php
/**
 * Plugin Name: E-Izin Magang App
 * Description: Aplikasi E-Izin Magang berbasis React. Gunakan shortcode [e_izin_magang] untuk menampilkan.
 * Version: 2.0
 * Author: Agil
 */

function e_izin_enqueue_scripts()
{
    // Cari file JS dan CSS di folder assets yang dihasilkan build
    $js_files = glob(plugin_dir_path(__FILE__) . 'assets/*.js');
    $css_files = glob(plugin_dir_path(__FILE__) . 'assets/*.css');

    if (!empty($js_files)) {
        $js_file = basename($js_files[0]);
        wp_enqueue_script('e-izin-react', plugin_dir_url(__FILE__) . 'assets/' . $js_file, array(), '2.0', true);
    }

    if (!empty($css_files)) {
        $css_file = basename($css_files[0]);
        wp_enqueue_style('e-izin-style', plugin_dir_url(__FILE__) . 'assets/' . $css_file, array(), '2.0');
    }
}
add_action('wp_enqueue_scripts', 'e_izin_enqueue_scripts');

function render_e_izin_app()
{
    return '<div id="e-izin-root"></div>';
}
add_shortcode('e_izin_magang', 'render_e_izin_app');
